//
//  ViewController.swift
//  tipcalc
//
//  Created by INFINITY on 1/14/15.
//  Copyright (c) 2015 ALL ONE SUN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var billField: UITextField!
    @IBOutlet weak var tipAmount: UILabel!
    @IBOutlet weak var totalAmount: UILabel!
    @IBAction func editChanged(sender: AnyObject) {
        var tipPercentages=[0.15,0.18,0.2]
        var tipPercent=tipPercentages[tipSelector.selectedSegmentIndex]
        var billAmount=billField.text._bridgeToObjectiveC().doubleValue
        var tip=billAmount*tipPercent
        var total=billAmount+tip
        
//        tipAmount.text="\(tip)"
//        totalAmount.text="\(total)"
        
        tipAmount.text=String(format: "$%.2f", tip)
        totalAmount.text=String(format: "$%.2f", total)
    }
    
    @IBAction func dismissKeyboard(sender: AnyObject) {view.endEditing(true)
    }
    @IBOutlet weak var tipSelector: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

